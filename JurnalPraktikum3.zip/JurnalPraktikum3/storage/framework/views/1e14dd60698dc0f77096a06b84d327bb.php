<div class="card">
    <h3>Pelapor: <?php echo e($item['nama']); ?></h3>
    <p><strong>Lokasi Kejadian:</strong> <?php echo e($item['lokasi']); ?></p>
    <p><strong>Tinggi Genangan Air:</strong> <?php echo e($item['tinggi_air']); ?> cm</p>
    <p><strong>Tanggal Lapor:</strong> <?php echo e($item['tanggal']); ?></p>
    
    <p><strong>Status Genangan:</strong> 
        <?php if($item['tinggi_air'] < 30): ?>
            <span class="badge bg-waspada">Waspada</span>
        <?php elseif($item['tinggi_air'] >= 30 && $item['tinggi_air'] <= 70): ?>
            <span class="badge bg-siaga">Siaga</span>
        <?php else: ?>
            <span class="badge bg-awas">Awas</span>
        <?php endif; ?>
    </p>
</div><?php /**PATH C:\xampp\htdocs\JurnalPraktikum3\resources\views/partials/laporan-card.blade.php ENDPATH**/ ?>