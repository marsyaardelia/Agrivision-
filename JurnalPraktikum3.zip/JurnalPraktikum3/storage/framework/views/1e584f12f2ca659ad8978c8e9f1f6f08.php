

<?php $__env->startSection('title', 'Buat Laporan Banjir'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Form Lapor Kejadian Banjir</h2>

    <form action="<?php echo e(route('lapor.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama">Nama Pelapor:</label>
            <input type="text" id="nama" name="nama" required placeholder="Masukkan nama lengkap">
        </div>

        <div class="form-group">
            <label for="lokasi">Lokasi Kejadian:</label>
            <input type="text" id="lokasi" name="lokasi" required placeholder="Contoh: Desa Dayeuhkolot RT 01/03">
        </div>

        <div class="form-group">
            <label for="tinggi_air">Tinggi Genangan Air (cm):</label>
            <input type="number" id="tinggi_air" name="tinggi_air" required placeholder="Masukkan ketinggian air dalam cm">
        </div>

        <button type="submit" class="btn">Kirim Laporan</button>
    </form>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\JurnalPraktikum3\resources\views/laporan/create.blade.php ENDPATH**/ ?>