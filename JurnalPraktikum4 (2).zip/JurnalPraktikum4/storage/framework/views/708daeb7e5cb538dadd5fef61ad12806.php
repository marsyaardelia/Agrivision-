<div style="padding: 12px; border: 1px solid <?php echo e($type === 'success' ? '#c3e6cb' : '#f5c6cb'); ?>;
 background-color: <?php echo e($type === 'success' ? '#d4edda' : '#f8d7da'); ?>; 
 color: <?php echo e($type === 'success' ? '#155724' : '#721c24'); ?>; 
 border-radius: 4px; margin-bottom: 15px;">
    <strong><?php echo e(ucfirst($type)); ?>:</strong> <?php echo e($message); ?>

</div>

<?php /**PATH C:\xampp\htdocs\JurnalPraktikum4\resources\views/components/alert.blade.php ENDPATH**/ ?>