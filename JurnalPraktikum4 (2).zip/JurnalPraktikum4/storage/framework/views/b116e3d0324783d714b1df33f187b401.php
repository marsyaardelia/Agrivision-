<div class="card">
    <div class="card-top">
        <div>
            <div class="pelapor-nama">Pelapor: <?php echo e($item->nama_pelapor); ?></div>
            <div class="pelapor-lokasi">Lokasi: <?php echo e($item->lokasi); ?></div>
        </div>
        <div>
            <?php if($item->tinggi_genangan < 30): ?>
                <span class="badge bg-waspada">Waspada</span>
            <?php elseif($item->tinggi_genangan >= 30 && $item->tinggi_genangan <= 70): ?>
                <span class="badge bg-siaga">Siaga</span>
            <?php else: ?>
                <span class="badge bg-awas">Awas</span>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-info">
        <div>Ketinggian Air: <span><?php echo e($item->tinggi_genangan); ?> cm</span></div>
        <div>Tanggal Kejadian: <span><?php echo e($item->tanggal_kejadian); ?></span></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\JurnalPraktikum4\resources\views/partials/laporan-card.blade.php ENDPATH**/ ?>