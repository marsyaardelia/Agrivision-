

<?php $__env->startSection('title', 'Daftar Laporan'); ?>

<?php $__env->startSection('content'); ?>
    <h2>Daftar Laporan Banjir Terkini</h2>

    <div class="laporan-grid">
        <?php $__empty_1 = true; $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('partials.laporan-card', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="grid-column: 1 / -1;">Belum ada laporan kejadian banjir saat ini.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\JurnalPraktikum4\resources\views/laporan/index.blade.php ENDPATH**/ ?>