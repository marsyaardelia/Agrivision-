function ActivityItem({ activity, onDelete }) {
  return (
    <li>
      {activity}
      <button onClick={() => onDelete(activity)}>Hapus</button>
    </li>
  );
}

export default ActivityItem;
