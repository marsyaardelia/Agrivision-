import { useState } from 'react';
import ActivityItem from './ActivityItem';
import './App.css';

function App() {
  const [activities, setActivities] = useState([
    'Belajar React',
    'Mengerjakan Praktikum',
    'Review Materi',
  ]);
  const [input, setInput] = useState('');

  const handleAdd = () => {
    if (input.trim() === '') return;
    setActivities([...activities, input]);
    setInput('');
  };

  const handleDelete = (activity) => {
    setActivities(activities.filter((a) => a !== activity));
  };

  return (
    <div>
      <h1>Daftar Aktivitas Mahasiswa</h1>

      <div className="input-area">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Masukkan aktivitas baru"
        />
        <button onClick={handleAdd}>Tambah</button>
      </div>

      {activities.length === 0 ? (
        <p className="empty-msg">Belum ada aktivitas</p>
      ) : (
        <>
          <p className="count-msg">Total aktivitas: {activities.length}</p>
          <ul>
            {activities.map((activity, index) => (
              <ActivityItem
                key={index}
                activity={activity}
                onDelete={handleDelete}
              />
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

export default App;
