<?php

include 'config/koneksi.php';
include 'Models/models.php';

class LaporanController{

    private $model;

    public function __construct($conn){

        $this->model =
            new models($conn);
    }

    public function index(){

        return $this->models->getAll();
    }

    public function store(){

        if(isset($_POST['simpan'])){

            $lokasi_sungai = $_POST['lokasi_sungai'];
            $waktu_pengukuran = $_POST['waktu_pengukuran'];
            $tinggi_air = $_POST['tinggi_air'];
            $deskripsi = $_POST['deskripsi'];

            if($inggi_air <= 50){
                $status = "Aman";
            }
            elseif($inggi_air <= 100){
                $status = "Waspada";
            }
            else{
                $status = "Bahaya";
            }

            $foto =
            $_FILES['foto_bukti']['name'];

            move_uploaded_file(
                $_FILES['foto_bukti']['tmp_name'],
                "uploads/".$foto
            );

            $this->model->insert(
                $_SESSION['id'],
                $lokasi_sungai,
                $waktu_pengukuran,
                $tinggi_air,
                $status_banjir,
                $deskripsi,
                $foto
            );

            header("Location:index.php?page=laporan");
        }
    }
}