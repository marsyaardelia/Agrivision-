<?php
session_start();
include 'koneksi.php';

$id = $_GET['id'];
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM laporan WHERE id='$id'"));

if(isset($_POST['update'])) {
    $lokasi_sungai = $_POST['lokasi_sungai'];
    $waktu_pengukuran = $_POST['waktu_pengukuran'];
    $tinggi_air = $_POST['tinggi_air'];
    $deskripsi = $_POST['deskripsi'];

    if($tinggi_air >= 0 && $tinggi_air <= 50) {
        $status = "Aman";
    } elseif($tinggi_air >= 51 && $tinggi_air <= 100) {
        $status = "Waspada";
    } else {
        $status = "Bahaya";
    }
    
    $foto = $_FILES['foto_bukti']['name'];
    if($foto != '') {
        unlink('uploads/' . $data['foto_bukti']);

        move_uploaded_file($_FILES['foto_bukti']['tmp_name'], 'uploads/' . $foto);
    } else {
        $foto = $data['foto_bukti'];
    }

    mysqli_query($conn, "UPDATE laporan SET
        lokasi_sungai='$lokasi_sungai',
        waktu_pengukuran='$waktu_pengukuran',
        tinggi_air='$tinggi_air',
        status_banjir='$status_banjir',
        deskripsi='$deskripsi',
        foto_bukti='$foto'
        WHERE id='$id'");

    header("Location: laporan.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Laporan</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">
    <h2>Edit Laporan</h2>

    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="lokasi" value="<?php echo $data['lokasi']; ?>" class="form-control mb-3">

        <input type="datetime-local" name="waktu_laporan" class="form-control mb-3">

        <input type="number" name="jumlah_kendaraan" value="<?php echo $data['jumlah_kendaraan']; ?>" class="form-control mb-3">

        <textarea name="deskripsi" class="form-control mb-3"><?php echo $data['deskripsi']; ?></textarea>

        <input type="file" name="foto_bukti" class="form-control mb-3">

        <button type="submit" name="update" class="btn btn-success">Update</button>
    </form>
</div>

<?php include 'footer.php'; ?>

</body>
</html>