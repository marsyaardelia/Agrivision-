<?php
session_start();
include 'koneksi.php';

if(!isset($_SESSION['id'])){
    header("Location: login.php");
}

function statusPengukuran($tinggi_air){

    if($tinggi_air >= 0 && $tinggi_air <= 50){
        return "Aman";
    }
    elseif($tinggi_air >= 51 && $tinggi_air <= 100){
        return "Waspada";
    }

    return "Bahaya";
}

if(isset($_POST['simpan'])){

    $lokasi_sungai = $_POST['lokasi_sungai'];
    $waktu_pengukuran = $_POST['waktu_pengukuran'];
    $tinggi_air = $_POST['tinggi_air'];
    $deskripsi = $_POST['deskripsi'];

    if(empty($lokasi)){
        die("Lokasi wajib diisi");
    }

    $status_banjir = statusBanjir($tinggi_air);

    $foto = $_FILES['foto_bukti']['name'];

    if($foto != ''){

        $allowed = ['jpg','jpeg','png'];

        $ext = strtolower(
            pathinfo($foto, PATHINFO_EXTENSION)
        );

        if(!in_array($ext,$allowed)){
            die("Format file harus JPG atau PNG");
        }

        if($_FILES['foto_bukti']['size'] > 2000000){
            die("Ukuran file maksimal 2MB");
        }

        move_uploaded_file(
            $_FILES['foto_bukti']['tmp_name'],
            'folderupload/'.$foto
        );
    }

    mysqli_query($conn,"
        INSERT INTO laporan(
            user_id,
            lokasi_sungai,
            waktu_pengukuran,
            tinggi_air,
            status_banjir,
            deskripsi,
            foto_bukti
        )
        VALUES(
            '{$_SESSION['id']}',
            '$lokasi_sungai',
            '$waktu_pengukuran',
            '$tinggi_air',
            '$status_banjir',
            '$deskripsi',
            '$foto_bukti'
        )
    ");

    header("Location: laporan.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Laporan</title>

    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

    <link rel="stylesheet"
    href="assets/style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container mt-5">

<h2>Tambah Laporan</h2>

<form method="POST" enctype="multipart/form-data">

<input
type="text"
name="lokasi_sungai"
placeholder="Lokasi_sungai"
class="form-control mb-3">

<input
type="datetime-local"
name="waktu_pengukuran"
class="form-control mb-3">

<input
type="number"
name="tinggi_air"
placeholder="Tinggi air"
class="form-control mb-3">

<textarea
name="deskripsi"
placeholder="Deskripsi"
class="form-control mb-3"></textarea>

<input
type="file"
name="foto_bukti"
class="form-control mb-3">

<button
type="submit"
name="simpan"
class="btn btn-primary">

Simpan

</button>

</form>

</div>

<?php include 'footer.php'; ?>

</body>
</html>