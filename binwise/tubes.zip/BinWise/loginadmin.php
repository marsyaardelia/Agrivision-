<?php
session_start();
include 'koneksi.php';

    if(isset($_POST['login'])){

    $nama=$_POST['nama'];
    $password=md5($_POST['password']);

    $cek=mysqli_query($conn,"
    SELECT * FROM users
    WHERE nama='$nama'
    AND password='$password'
    AND role='admin'
    ");

    if(mysqli_num_rows($cek)>0){

    $data=mysqli_fetch_assoc($cek);

    $_SESSION['nama']=$data['nama'];
    $_SESSION['role']='admin';

    header("Location: dashboardadmin.php");
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login Admin</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="container">

<div class="left">
<div class="hero">
    <div class="hero-text">
        <h1>Selamat Datang di BinWise</h1>
        <h2>Kelola data sampah dengan lebih mudah dan efisien</h2>
    </div>

    <div class="hero-image">
        <img src="images/tempatsampah.png" alt="">
    </div>
</div>
</div>

<div class="right">

    <div class="card">

        <h2>Masuk</h2>
        <p>Silahkan masuk untuk melanjutkan</p>

        <form method="POST">

            <div class="input-group">
                <label>Nama Lengkap</label>
                <input type="text"
                       name="nama"
                       placeholder="masukkan nama lengkap"
                       required>
            </div>

            <div class="input-group">
                <label>Kata Sandi</label>
                <input type="password"
                       name="password"
                       placeholder="masukkan kata sandi"
                       required>
            </div>

            <a href="forget.php" class="forgot">
                Lupa kata sandi?
            </a>

            <button type="submit"
                    name="login"
                    class="btn">
                Masuk
            </button>

        </form>

    </div>

</div>

</body>
</html>